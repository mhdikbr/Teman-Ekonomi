"""Cek legalitas platform pinjaman online.

Prinsip desain:
- Nama yang COCOK PERSIS dengan daftar berizin -> LICENSED.
- Nama yang MIRIP (typo / tiruan) TIDAK pernah otomatis dianggap legal: bot minta konfirmasi dulu,
  karena aplikasi ilegal sering memakai nama yang mirip dengan yang resmi.
- Tidak ada di daftar berizin -> NOT_LISTED (bukan otomatis "ilegal": produk bank/perusahaan
  pembiayaan memang tidak masuk daftar pindar). Kalau daftar belum lengkap, kata-katanya lebih hati-hati.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Tuple

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
FUZZY_THRESHOLD = 0.82
_NOISE = {"pt", "tbk", "aplikasi", "app", "pinjaman", "pinjol", "pindar", "online"}


def normalize(text: str) -> str:
    """'Rupiah Cepat' / 'rupiahcepat' / 'PT. RupiahCepat' -> 'rupiahcepat'."""
    tokens = re.findall(r"[a-z0-9]+", (text or "").lower())
    return "".join(t for t in tokens if t not in _NOISE)


class Status(str, Enum):
    LICENSED = "licensed"
    REPORTED_ILLEGAL = "reported_illegal"
    POSSIBLE_MATCH = "possible_match"
    NOT_LISTED = "not_listed"


@dataclass(frozen=True)
class Platform:
    name: str
    company: str = ""
    aliases: Tuple[str, ...] = ()

    def keys(self) -> set:
        raw = (self.name, self.company, *self.aliases)
        return {k for k in (normalize(x) for x in raw) if k}


@dataclass
class CheckResult:
    status: Status
    query: str
    platform: Optional[Platform] = None
    # Untuk POSSIBLE_MATCH: [(platform, LICENSED | REPORTED_ILLEGAL)]
    suggestions: List[Tuple[Platform, Status]] = field(default_factory=list)


def _index(platforms: List[Platform]) -> Dict[str, Platform]:
    idx: Dict[str, Platform] = {}
    for p in platforms:
        for k in p.keys():
            idx.setdefault(k, p)
    return idx


def _load(path: Path):
    data = json.loads(path.read_text(encoding="utf-8"))
    platforms = [
        Platform(name=p["name"], company=p.get("company", ""), aliases=tuple(p.get("aliases", [])))
        for p in data.get("platforms", [])
    ]
    return data, platforms


class Registry:
    def __init__(
        self,
        licensed: List[Platform],
        illegal: List[Platform] = (),
        *,
        licensed_as_of: Optional[str] = None,
        licensed_source: str = "",
        complete: bool = False,
        illegal_as_of: Optional[str] = None,
        illegal_source: str = "",
    ):
        self.licensed = list(licensed)
        self.illegal = list(illegal)
        self.licensed_as_of = licensed_as_of
        self.licensed_source = licensed_source
        self.complete = complete
        self.illegal_as_of = illegal_as_of
        self.illegal_source = illegal_source
        self._lic_idx = _index(self.licensed)
        self._ill_idx = _index(self.illegal)

    @classmethod
    def from_files(cls, licensed_path=None, illegal_path=None) -> "Registry":
        lic_meta, lic = _load(Path(licensed_path) if licensed_path else DATA_DIR / "licensed_platforms.json")
        ill_path = Path(illegal_path) if illegal_path else DATA_DIR / "illegal_platforms.json"
        ill_meta, ill = _load(ill_path) if ill_path.exists() else ({}, [])
        return cls(
            lic,
            ill,
            licensed_as_of=lic_meta.get("as_of"),
            licensed_source=lic_meta.get("source", ""),
            complete=bool(lic_meta.get("complete", False)),
            illegal_as_of=ill_meta.get("as_of"),
            illegal_source=ill_meta.get("source", ""),
        )

    def check(self, query: str) -> CheckResult:
        q = normalize(query)
        if not q:
            return CheckResult(Status.NOT_LISTED, query)

        # Cocok persis. Daftar ilegal dicek duluan: kalau ada di dua daftar, peringatan yang menang.
        if q in self._ill_idx:
            return CheckResult(Status.REPORTED_ILLEGAL, query, self._ill_idx[q])
        if q in self._lic_idx:
            return CheckResult(Status.LICENSED, query, self._lic_idx[q])

        # Mirip (typo / nama tiruan) -> minta konfirmasi, jangan langsung diputuskan.
        if len(q) >= 4:
            scored = []
            for status, idx in ((Status.REPORTED_ILLEGAL, self._ill_idx), (Status.LICENSED, self._lic_idx)):
                for key, platform in idx.items():
                    ratio = SequenceMatcher(None, q, key).ratio()
                    if ratio >= FUZZY_THRESHOLD:
                        scored.append((ratio, platform, status))
            scored.sort(key=lambda t: -t[0])
            seen, suggestions = set(), []
            for _, platform, status in scored:
                if (platform.name, status) in seen:
                    continue
                seen.add((platform.name, status))
                suggestions.append((platform, status))
                if len(suggestions) == 3:
                    break
            if suggestions:
                return CheckResult(Status.POSSIBLE_MATCH, query, suggestions=suggestions)

        return CheckResult(Status.NOT_LISTED, query)
