"""Kalkulator kemampuan bayar: apakah pinjaman ini masuk akal dengan penghasilan & pengeluaranmu?

Patokan di bawah ini adalah HEURISTIK umum perencana keuangan (bukan aturan OJK dan bukan nasihat
keuangan resmi). Semua bisa diubah lewat `Policy`.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import List

from .formatting import fmt_pct, fmt_rp


@dataclass(frozen=True)
class Policy:
    max_dsr: float = 0.30            # total cicilan <= 30% penghasilan = batas aman
    avoid_dsr: float = 0.40          # di atas ini: sebaiknya jangan
    min_buffer_ratio: float = 0.10   # sisa uang setelah cicilan minimal 10% penghasilan
    high_daily_cost_pct: float = 0.4  # biaya >0,4%/hari dianggap mahal (heuristik, bukan batas OJK)
    round_to: int = 50_000           # pembulatan plafon aman ke bawah


class Verdict(str, Enum):
    SAFE = "safe"
    CAUTION = "caution"
    AVOID = "avoid"


@dataclass(frozen=True)
class Profile:
    income: int                  # penghasilan bersih per bulan (yang benar-benar masuk)
    expenses: int                # pengeluaran wajib per bulan, di luar cicilan utang
    existing_installments: int = 0


@dataclass(frozen=True)
class LoanOffer:
    principal: int               # uang yang diterima
    total_repay: int             # total yang harus dikembalikan (pokok + bunga + admin)
    tenor_days: int
    to_pay_other_debt: bool = False


@dataclass
class Assessment:
    verdict: Verdict
    n_installments: int
    monthly_installment: int
    free_before: int
    free_after: int
    dsr_before: float
    dsr_after: float
    cost_pct: float
    daily_cost_pct: float
    max_safe_installment: int
    max_safe_principal: int
    reasons: List[str] = field(default_factory=list)


def assess(profile: Profile, offer: LoanOffer, policy: Policy = Policy()) -> Assessment:
    if profile.income <= 0:
        raise ValueError("Penghasilan harus lebih dari 0.")
    if min(profile.expenses, profile.existing_installments) < 0:
        raise ValueError("Pengeluaran dan cicilan tidak boleh negatif.")
    if offer.principal <= 0:
        raise ValueError("Jumlah pinjaman harus lebih dari 0.")
    if offer.total_repay < offer.principal:
        raise ValueError("Total pengembalian tidak boleh lebih kecil dari jumlah pinjaman.")
    if offer.tenor_days < 1:
        raise ValueError("Tenor minimal 1 hari.")

    income = profile.income
    n = max(1, math.ceil(offer.tenor_days / 30))
    monthly = math.ceil(offer.total_repay / n)

    free_before = income - profile.expenses - profile.existing_installments
    free_after = free_before - monthly
    dsr_before = profile.existing_installments / income
    dsr_after = (profile.existing_installments + monthly) / income
    cost_pct = (offer.total_repay - offer.principal) / offer.principal * 100
    daily_cost = cost_pct / offer.tenor_days

    buffer = policy.min_buffer_ratio * income
    cap_dsr = policy.max_dsr * income - profile.existing_installments
    cap_cash = free_before - buffer
    max_inst = max(0.0, min(cap_dsr, cap_cash))
    ratio = offer.total_repay / offer.principal
    max_principal = int(max_inst * n / ratio // policy.round_to * policy.round_to)

    avoid = free_after < 0 or dsr_after > policy.avoid_dsr
    caution = (
        dsr_after > policy.max_dsr
        or free_after < buffer
        or daily_cost > policy.high_daily_cost_pct
        or offer.to_pay_other_debt
    )
    verdict = Verdict.AVOID if avoid else Verdict.CAUTION if caution else Verdict.SAFE

    reasons: List[str] = []
    if free_before <= 0:
        reasons.append("Penghasilanmu sudah habis untuk pengeluaran + cicilan yang ada, bahkan sebelum pinjaman baru.")
    elif dsr_before > policy.max_dsr:
        reasons.append(
            f"Cicilan berjalan sudah {fmt_pct(dsr_before * 100, 0)} dari penghasilan, di atas batas aman "
            f"{fmt_pct(policy.max_dsr * 100, 0)}."
        )
    if free_after < 0:
        reasons.append(
            f"Setelah cicilan baru, uangmu minus {fmt_rp(-free_after)} per bulan: hampir pasti berujung "
            "gali lubang tutup lubang."
        )
    elif free_after < buffer:
        reasons.append(
            f"Sisa uang setelah cicilan cuma {fmt_rp(free_after)} (kurang dari {fmt_rp(buffer)}, "
            f"{fmt_pct(policy.min_buffer_ratio * 100, 0)} penghasilan): tipis kalau ada kebutuhan mendadak."
        )
    if dsr_after > policy.avoid_dsr:
        reasons.append(
            f"Total cicilan jadi {fmt_pct(dsr_after * 100, 0)} dari penghasilan, jauh di atas batas aman."
        )
    elif dsr_after > policy.max_dsr:
        reasons.append(
            f"Total cicilan jadi {fmt_pct(dsr_after * 100, 0)} dari penghasilan, di atas batas aman "
            f"{fmt_pct(policy.max_dsr * 100, 0)}."
        )
    if daily_cost > policy.high_daily_cost_pct:
        reasons.append(
            f"Biaya sekitar {fmt_pct(daily_cost, 2)} per hari tergolong mahal. Bandingkan dengan opsi lain."
        )
    if offer.to_pay_other_debt:
        reasons.append(
            "Pinjaman untuk menutup utang lain berisiko menumpuk. Bicarakan dulu keringanan atau "
            "penjadwalan ulang dengan pemberi pinjaman awal."
        )
    if not reasons:
        reasons.append("Cicilan masih di bawah batas aman dan sisa uangmu cukup.")

    return Assessment(
        verdict=verdict,
        n_installments=n,
        monthly_installment=monthly,
        free_before=free_before,
        free_after=free_after,
        dsr_before=dsr_before,
        dsr_after=dsr_after,
        cost_pct=cost_pct,
        daily_cost_pct=daily_cost,
        max_safe_installment=int(max_inst),
        max_safe_principal=max_principal,
        reasons=reasons,
    )
