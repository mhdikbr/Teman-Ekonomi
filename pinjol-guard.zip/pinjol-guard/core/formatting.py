"""Format angka gaya Indonesia (titik ribuan, koma desimal)."""
from __future__ import annotations


def fmt_rp(n: float) -> str:
    sign = "-" if n < 0 else ""
    return f"{sign}Rp {abs(int(round(n))):,}".replace(",", ".")


def fmt_pct(x: float, digits: int = 1) -> str:
    return f"{x:.{digits}f}".replace(".", ",") + "%"
