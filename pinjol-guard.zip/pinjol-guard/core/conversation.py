"""Alur percakapan bot. Tidak tahu apa-apa soal channel: CLI, API, WhatsApp, atau Telegram
cukup memanggil `Bot.handle(session, teks)` dan mengirim balik daftar balasan yang dihasilkan.
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

from .affordability import Assessment, LoanOffer, Policy, Profile, Verdict, assess
from .checker import Platform, Registry, Status, normalize
from .formatting import fmt_pct, fmt_rp
from .parsing import parse_days, parse_rupiah, parse_yes_no

OJK_CONTACT = "OJK 157 (telepon) atau WhatsApp 081 157 157 157"

GREETING = (
    "Halo! 👋 Aku *PinjolGuard* (versi prototype). Aku bisa bantu:\n"
    "1️⃣ Cek pinjol/pindar itu berizin OJK atau tidak\n"
    "2️⃣ Hitung apakah penghasilanmu cukup untuk ambil pinjaman\n"
    "3️⃣ Dua-duanya\n\n"
    "Balas angka 1, 2, atau 3. Ketik *menu* kapan saja untuk mulai dari awal.\n"
    "Data yang kamu ketik hanya dipakai untuk hitungan di chat ini."
)
HELP = (
    "Perintah: *menu* (mulai ulang), *bantuan* (pesan ini).\n"
    "Angka bisa ditulis bebas: 5jt, 2,5 juta, 750rb, atau 5.000.000.\n\n" + GREETING
)
ASK_NAME = "Tulis nama aplikasi/platform pinjamannya ya. Contoh: RupiahCepat"
BAD_NUMBER = "Aku belum paham angkanya 😅 Coba tulis seperti: 5jt, 750rb, atau 5.000.000"
INCOME_PROMPT = (
    "💰 Berapa *penghasilan bersih per bulan* kamu? Isi yang benar-benar masuk, rata-rata 3 bulan terakhir.\n"
    "Contoh: 5jt atau 5.000.000\n\n"
    "Isi jujur ya. Angka ini cuma untuk hitunganmu, bukan untuk diajukan ke aplikasi."
)
EXPENSES_PROMPT = (
    "🏠 Berapa *pengeluaran wajib per bulan*? (makan, kos/rumah, listrik, transport, sekolah, dll, "
    "di luar cicilan utang)"
)
INSTALLMENTS_PROMPT = (
    "💳 Berapa total *cicilan/utang yang sedang berjalan* per bulan? (KPR, motor, paylater, pinjol lain). "
    "Kalau tidak ada, ketik 0."
)
PRINCIPAL_PROMPT = "💵 Berapa *jumlah pinjaman* yang mau kamu ambil (uang yang kamu terima)?"
TOTAL_REPAY_PROMPT = (
    "🧾 Berapa *total yang harus dikembalikan* (pokok + bunga + biaya admin)? "
    "Lihat di halaman konfirmasi aplikasi sebelum klik setuju."
)
TENOR_PROMPT = "📅 Tenornya berapa lama? Contoh: 14 hari, 30 hari, atau 3 bulan."
OTHER_DEBT_PROMPT = "Terakhir: pinjaman ini untuk *menutup utang/cicilan lain*? (ya/tidak)"

RESET_WORDS = {"menu", "batal", "reset", "ulang", "mulai", "/start", "/menu"}
HELP_WORDS = {"bantuan", "help", "/help", "?"}
MENU_CHOICES = {
    "1": "check", "cek": "check", "cek legalitas": "check",
    "2": "calc", "hitung": "calc", "simulasi": "calc",
    "3": "both", "keduanya": "both", "semua": "both",
}


class State(str, Enum):
    MENU = "menu"
    CHECK_NAME = "check_name"
    CONFIRM_MATCH = "confirm_match"
    ASK_CONTINUE = "ask_continue"
    INCOME = "income"
    EXPENSES = "expenses"
    INSTALLMENTS = "installments"
    PRINCIPAL = "principal"
    TOTAL_REPAY = "total_repay"
    TENOR = "tenor"
    OTHER_DEBT = "other_debt"
    AFTER_RESULT = "after_result"


@dataclass
class Session:
    state: State = State.MENU
    data: Dict = field(default_factory=dict)
    started: bool = False
    last_seen: float = field(default_factory=time.time)

    def touch(self) -> None:
        self.last_seen = time.time()

    def reset(self) -> None:
        self.state = State.MENU
        self.data = {}


class Bot:
    def __init__(self, registry: Registry, policy: Optional[Policy] = None):
        self.registry = registry
        self.policy = policy or Policy()

    # ------------------------------------------------------------------ entry point
    def handle(self, session: Session, text: str) -> List[str]:
        session.touch()
        raw = (text or "").strip()
        low = raw.lower()
        if not session.started or low in RESET_WORDS:
            session.reset()
            session.started = True
            return [GREETING]
        if low in HELP_WORDS:
            return [HELP]
        return getattr(self, "_on_" + session.state.value)(session, raw)

    # ------------------------------------------------------------------ menu
    def _on_menu(self, s: Session, raw: str) -> List[str]:
        choice = MENU_CHOICES.get(raw.lower())
        if choice == "calc":
            s.data["chain"] = False
            return self._start_calc(s)
        if choice in ("check", "both"):
            s.data["chain"] = choice == "both"
            s.state = State.CHECK_NAME
            return [ASK_NAME]
        return ["Pilih angka 1, 2, atau 3 ya 🙂", GREETING]

    def _start_calc(self, s: Session) -> List[str]:
        s.state = State.INCOME
        return [INCOME_PROMPT]

    # ------------------------------------------------------------------ cek legalitas
    def _on_check_name(self, s: Session, raw: str) -> List[str]:
        if not normalize(raw):
            return [ASK_NAME]
        res = self.registry.check(raw)
        if res.status is Status.POSSIBLE_MATCH:
            s.data["query"] = raw
            s.data["suggestions"] = res.suggestions
            s.state = State.CONFIRM_MATCH
            lines = [f"Aku nggak nemu persis *{raw}*, tapi ada yang mirip:"]
            for i, (p, st) in enumerate(res.suggestions, 1):
                tag = "berizin OJK" if st is Status.LICENSED else "masuk daftar ILEGAL"
                lines.append(f"{i}. {p.name} ({tag})")
            lines.append("Balas nomor yang kamu maksud, atau *bukan* kalau bukan salah satunya. "
                         "(Aplikasi tiruan sering memakai nama yang mirip, jadi aku tanya dulu.)")
            return ["\n".join(lines)]
        return self._report(s, res.status, res.platform, raw)

    def _on_confirm_match(self, s: Session, raw: str) -> List[str]:
        suggestions = s.data.get("suggestions", [])
        yn = parse_yes_no(raw)
        if yn is False:
            return self._report(s, Status.NOT_LISTED, None, s.data.get("query", ""))
        # [0-9] eksplisit: str.isdigit() juga true untuk karakter seperti "²", dan int("²") akan error.
        if re.fullmatch(r"[0-9]+", raw) and 1 <= int(raw) <= len(suggestions):
            platform, status = suggestions[int(raw) - 1]
            return self._report(s, status, platform, s.data.get("query", ""))
        if yn is True and len(suggestions) == 1:
            platform, status = suggestions[0]
            return self._report(s, status, platform, s.data.get("query", ""))
        return [f"Balas nomor pilihan (1-{len(suggestions)}) atau *bukan*."]

    def _report(self, s: Session, status: Status, platform: Optional[Platform], query: str) -> List[str]:
        chain = bool(s.data.get("chain"))
        r = self.registry

        if status is Status.LICENSED and platform:
            company = f" ({platform.company})" if platform.company else ""
            as_of = f" (data per {r.licensed_as_of})" if r.licensed_as_of else ""
            text = (
                f"✅ *{platform.name}*{company} tercatat *berizin OJK*{as_of}.\n\n"
                "Berizin belum tentu cocok untuk kondisi keuanganmu, dan nama resmi sering ditiru aplikasi palsu. "
                f"Unduh hanya dari tautan resmi di situs perusahaannya, dan cek ke {OJK_CONTACT} kalau ragu."
            )
            if chain:
                s.state = State.INCOME
                return [text, "Lanjut ke hitungan ya.", INCOME_PROMPT]
            s.state = State.ASK_CONTINUE
            return [text, "Mau lanjut hitung apakah penghasilanmu cukup untuk pinjaman ini? (ya/tidak)"]

        if status is Status.REPORTED_ILLEGAL and platform:
            source = f" ({r.illegal_source})" if r.illegal_source else ""
            s.reset()
            return [
                f"🚫 *{platform.name}* masuk daftar layanan pinjaman *ILEGAL*{source}.\n\n"
                "Jangan pinjam, jangan beri akses kontak/galeri/lokasi, dan jangan klik tautan pencairan. "
                f"Kalau sudah terlanjur atau diteror penagih, lapor ke Satgas PASTI atau {OJK_CONTACT}.",
                "Ketik *menu* untuk cek platform lain.",
            ]

        # NOT_LISTED
        if r.complete:
            head = (
                f"⚠️ *{query}* tidak ada di daftar pindar berizin OJK"
                f"{f' (data per {r.licensed_as_of})' if r.licensed_as_of else ''}. "
                "Anggap *belum terbukti legal*."
            )
        else:
            head = (
                f"❓ *{query}* tidak ketemu di data yang kupunya (daftar di prototype ini belum lengkap), "
                "jadi aku *belum bisa bilang legal*."
            )
        s.reset()
        return [
            head + f"\n\nCek status izinnya ke {OJK_CONTACT}. Catatan: paylater/kredit dari bank atau perusahaan "
            "pembiayaan memang tidak masuk daftar pindar, tapi tetap bisa dicek ke OJK.\n\n"
            "Selama belum terkonfirmasi, jangan beri akses kontak/galeri dan jangan transfer biaya apa pun di muka.",
            "Ketik *menu* untuk cek platform lain.",
        ]

    def _on_ask_continue(self, s: Session, raw: str) -> List[str]:
        yn = parse_yes_no(raw)
        if yn is True:
            return self._start_calc(s)
        if yn is False:
            s.reset()
            return ["Siap 👍 Ketik *menu* kalau mau lanjut nanti."]
        return ["Mau lanjut hitung kemampuan bayar? Jawab *ya* atau *tidak*."]

    # ------------------------------------------------------------------ hitung kemampuan bayar
    def _number_step(self, s: Session, raw: str, key: str, next_state: State, prompt: str,
                     allow_zero: bool = False) -> List[str]:
        n = parse_rupiah(raw)
        if n is None:
            return [BAD_NUMBER]
        if n == 0 and not allow_zero:
            return ["Angkanya harus lebih dari 0 ya."]
        s.data[key] = n
        s.state = next_state
        return [prompt]

    def _on_income(self, s: Session, raw: str) -> List[str]:
        return self._number_step(s, raw, "income", State.EXPENSES, EXPENSES_PROMPT)

    def _on_expenses(self, s: Session, raw: str) -> List[str]:
        return self._number_step(s, raw, "expenses", State.INSTALLMENTS, INSTALLMENTS_PROMPT, allow_zero=True)

    def _on_installments(self, s: Session, raw: str) -> List[str]:
        return self._number_step(s, raw, "installments", State.PRINCIPAL, PRINCIPAL_PROMPT, allow_zero=True)

    def _on_principal(self, s: Session, raw: str) -> List[str]:
        return self._number_step(s, raw, "principal", State.TOTAL_REPAY, TOTAL_REPAY_PROMPT)

    def _on_total_repay(self, s: Session, raw: str) -> List[str]:
        n = parse_rupiah(raw)
        if n is None:
            return [BAD_NUMBER]
        principal = s.data["principal"]
        if n < principal:
            return [f"Total yang dikembalikan tidak mungkin lebih kecil dari pinjaman ({fmt_rp(principal)}). "
                    "Cek lagi ya."]
        s.data["total_repay"] = n
        s.state = State.TENOR
        return [TENOR_PROMPT]

    def _on_tenor(self, s: Session, raw: str) -> List[str]:
        days = parse_days(raw)
        if days is None:
            return ["Tenornya belum kebaca. Tulis seperti: 14 hari, 30 hari, atau 3 bulan."]
        s.data["tenor_days"] = days
        s.state = State.OTHER_DEBT
        return [OTHER_DEBT_PROMPT]

    def _on_other_debt(self, s: Session, raw: str) -> List[str]:
        yn = parse_yes_no(raw)
        if yn is None:
            return ["Jawab *ya* atau *tidak* ya."]
        d = s.data
        profile = Profile(d["income"], d["expenses"], d["installments"])
        offer = LoanOffer(d["principal"], d["total_repay"], d["tenor_days"], to_pay_other_debt=yn)
        result = assess(profile, offer, self.policy)
        s.state = State.AFTER_RESULT
        return [self.format_result(profile, offer, result)]

    def _on_after_result(self, s: Session, raw: str) -> List[str]:
        if raw.lower() in {"lagi", "coba lagi", "lagi dong"}:
            for k in ("principal", "total_repay", "tenor_days"):
                s.data.pop(k, None)
            s.state = State.PRINCIPAL
            return ["Oke, penghasilan & pengeluaranmu tetap kupakai.", PRINCIPAL_PROMPT]
        return ["Ketik *lagi* untuk coba angka pinjaman lain (data penghasilanmu tetap dipakai), "
                "atau *menu* untuk mulai dari awal."]

    # ------------------------------------------------------------------ tampilan hasil
    def format_result(self, p: Profile, o: LoanOffer, a: Assessment) -> str:
        pol = self.policy
        lines = [
            "📊 *Hasil hitungan*",
            f"Penghasilan: {fmt_rp(p.income)}",
            f"Pengeluaran wajib: {fmt_rp(p.expenses)}",
            f"Cicilan berjalan: {fmt_rp(p.existing_installments)}",
            f"Sisa per bulan sekarang: {fmt_rp(a.free_before)}",
            "",
            f"Pinjaman {fmt_rp(o.principal)} → bayar balik {fmt_rp(o.total_repay)} dalam {o.tenor_days} hari",
        ]
        if a.n_installments == 1:
            lines.append(f"Dibayar sekali: {fmt_rp(a.monthly_installment)}")
        else:
            lines.append(f"Cicilan baru: {a.n_installments}× {fmt_rp(a.monthly_installment)} per bulan")
        lines += [
            f"Biaya pinjaman: {fmt_pct(a.cost_pct)} (±{fmt_pct(a.daily_cost_pct, 2)} per hari)",
            "",
            f"Beban cicilan: {fmt_pct(a.dsr_before * 100, 0)} → {fmt_pct(a.dsr_after * 100, 0)} dari penghasilan "
            f"(batas aman ±{fmt_pct(pol.max_dsr * 100, 0)})",
            f"Sisa uang setelah cicilan: {fmt_rp(a.free_after)}",
            "",
        ]
        head = {
            Verdict.SAFE: "✅ *Relatif aman*",
            Verdict.CAUTION: "⚠️ *Hati-hati*",
            Verdict.AVOID: "🛑 *Sebaiknya jangan diambil*",
        }[a.verdict]
        lines.append(head)
        lines += [f"• {r}" for r in a.reasons]
        lines.append("")
        if a.max_safe_principal > 0:
            lines.append(
                f"Plafon aman untuk kondisimu (dengan biaya & tenor yang sama): ± {fmt_rp(a.max_safe_principal)}. "
                "Ambil sebesar kebutuhanmu, bukan sebesar limit yang ditawarkan aplikasi."
            )
        else:
            lines.append("Plafon aman untuk kondisimu saat ini: Rp 0. Sebaiknya tidak menambah pinjaman dulu.")
        lines.append("")
        lines.append("Ini hitungan bantu-bantu dengan patokan umum (cicilan ≤30% penghasilan), "
                     "bukan nasihat keuangan resmi.")
        lines.append("Ketik *lagi* untuk coba angka pinjaman lain, atau *menu*.")
        return "\n".join(lines)
