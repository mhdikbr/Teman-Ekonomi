"""Parser input chat (bahasa sehari-hari) menjadi angka / ya-tidak."""
from __future__ import annotations

import re
from typing import Optional

_SUFFIX = {"jt": 1_000_000, "juta": 1_000_000, "rb": 1_000, "ribu": 1_000, "k": 1_000}
# re.ASCII: hanya digit 0-9 (bukan digit Unicode lain), supaya sama persis dengan versi web (JavaScript).
_WITH_SUFFIX = re.compile(r"(\d+(?:[.,]\d+)?)(jt|juta|rb|ribu|k)", re.ASCII)
_PLAIN = re.compile(r"\d{1,3}(?:[.,]\d{3})+|\d+", re.ASCII)
_DAYS = re.compile(r"(\d+)\s*(hari|hr|minggu|mgg|bulan|bln)?", re.ASCII)

# Batas kewajaran (Rp 1 triliun). Menolak angka absurd, dan menjaga hitungan tetap presisi di JavaScript.
MAX_RUPIAH = 10**12

_YES = {"ya", "y", "iya", "yes", "ok", "oke", "okay", "lanjut", "boleh", "yoi", "sip", "betul", "benar"}
_NO = {"tidak", "tdk", "nggak", "ngga", "gak", "ga", "enggak", "engga", "no", "n", "nope", "bukan", "skip"}


def parse_rupiah(text: str) -> Optional[int]:
    """'5jt' -> 5000000, '2,5 juta' -> 2500000, '750rb' -> 750000, 'Rp 5.000.000' -> 5000000.

    Tanpa akhiran (jt/rb/k), titik/koma dianggap pemisah ribuan. Kalau tidak paham -> None.
    """
    s = (text or "").strip().lower()
    s = re.sub(r"^rp\.?", "", s).replace(" ", "")
    if not s:
        return None
    m = _WITH_SUFFIX.fullmatch(s)
    if m:
        value = float(m.group(1).replace(",", "."))
        n = int(round(value * _SUFFIX[m.group(2)]))
    elif _PLAIN.fullmatch(s):
        n = int(re.sub(r"[.,]", "", s))
    else:
        return None
    return n if n <= MAX_RUPIAH else None


def parse_days(text: str) -> Optional[int]:
    """'30' -> 30, '14 hari' -> 14, '2 minggu' -> 14, '3 bulan' -> 90. Batas 1..3650 hari."""
    s = (text or "").strip().lower()
    m = _DAYS.fullmatch(s)
    if not m:
        return None
    mult = {"minggu": 7, "mgg": 7, "bulan": 30, "bln": 30}.get(m.group(2), 1)
    days = int(m.group(1)) * mult
    return days if 1 <= days <= 3650 else None


def parse_yes_no(text: str) -> Optional[bool]:
    s = (text or "").strip().lower().strip("!.?")
    if s in _YES:
        return True
    if s in _NO:
        return False
    return None
