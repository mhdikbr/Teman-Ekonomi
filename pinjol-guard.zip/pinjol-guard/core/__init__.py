"""PinjolGuard - logika inti yang dipakai bersama oleh semua versi (CLI, API, WhatsApp, Telegram)."""
