"""Satu perintah untuk memastikan versi web (JavaScript) identik dengan versi Python.

    python tools/check_web.py

Langkah: (1) Python membuat data acuan, (2) Node menjalankan tes yang membandingkan hasil JS dengan acuan itu.
Butuh Node.js 18+ (hanya untuk tes; menjalankan situsnya tidak butuh Node).
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    node = shutil.which("node")
    if not node:
        print("Node.js tidak ditemukan. Pasang Node 18+ untuk menjalankan tes versi web.", file=sys.stderr)
        return 2
    gen = subprocess.run([sys.executable, str(ROOT / "tools" / "make_golden.py")])
    if gen.returncode:
        return gen.returncode
    tests = sorted(str(p) for p in (ROOT / "web" / "tests").glob("*.test.mjs"))
    return subprocess.run([node, "--test", *tests]).returncode


if __name__ == "__main__":
    sys.exit(main())
