"""Ubah CSV daftar penyelenggara berizin (dari situs OJK) menjadi data/licensed_platforms.json.

Kolom CSV: name,company,aliases      (aliases dipisah tanda |, boleh kosong)

Contoh:
    python tools/csv_to_json.py daftar_ojk.csv --as-of 2026-08-31 --complete
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

DEFAULT_OUT = Path(__file__).resolve().parent.parent / "data" / "licensed_platforms.json"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("csv_file")
    ap.add_argument("--as-of", required=True, help="tanggal data OJK, mis. 2026-08-31")
    ap.add_argument("--source", default="OJK - Penyelenggara LPBBTI/Fintech Lending Berizin")
    ap.add_argument("--complete", action="store_true",
                    help="tandai bahwa daftar ini LENGKAP (bot jadi lebih tegas untuk nama yang tidak ada)")
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    args = ap.parse_args()

    platforms = []
    with open(args.csv_file, newline="", encoding="utf-8-sig") as f:
        for i, row in enumerate(csv.DictReader(f), start=2):
            name = (row.get("name") or "").strip()
            if not name:
                raise SystemExit(f"Baris {i}: kolom 'name' kosong")
            aliases = [a.strip() for a in (row.get("aliases") or "").split("|") if a.strip()]
            platforms.append({"name": name, "company": (row.get("company") or "").strip(), "aliases": aliases})

    out = {"as_of": args.as_of, "source": args.source, "complete": args.complete, "platforms": platforms}
    Path(args.out).write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"{len(platforms)} platform ditulis ke {args.out}")


if __name__ == "__main__":
    main()
