"""Rakit situs statis ke folder _site/ (dipakai GitHub Actions dan untuk uji lokal).

    python tools/build_web.py
    python -m http.server -d _site 8080      # lalu buka http://localhost:8080

Isi _site: semua isi web/ (kecuali tes), ditambah data/*.json dari repo (satu sumber data untuk semua versi).
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"
DATA = ROOT / "data"
OUT = ROOT / "_site"
SKIP = shutil.ignore_patterns("tests", "package.json", "__pycache__", ".generated", "*.test.mjs")


def main() -> int:
    for name in ("licensed_platforms.json", "illegal_platforms.json"):
        path = DATA / name
        if not path.exists():
            print(f"Kurang file data: {path}", file=sys.stderr)
            return 1
        json.loads(path.read_text(encoding="utf-8"))  # gagal lebih awal kalau JSON rusak

    if OUT.exists():
        shutil.rmtree(OUT)
    shutil.copytree(WEB, OUT, ignore=SKIP)
    (OUT / "data").mkdir(exist_ok=True)
    for name in ("licensed_platforms.json", "illegal_platforms.json"):
        shutil.copy2(DATA / name, OUT / "data" / name)
    (OUT / ".nojekyll").write_text("", encoding="utf-8")  # GitHub Pages: sajikan file apa adanya

    files = sorted(p.relative_to(OUT).as_posix() for p in OUT.rglob("*") if p.is_file())
    print(f"_site siap ({len(files)} file):")
    for f in files:
        print("  ", f)
    return 0


if __name__ == "__main__":
    sys.exit(main())
