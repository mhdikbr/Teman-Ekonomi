"""Hasilkan data acuan dari implementasi Python, untuk dibandingkan dengan versi web (JavaScript).

Python = kunci jawaban. Tes JS (web/tests/*.test.mjs) harus menghasilkan balasan yang sama persis.
Isi: skenario tulisan tangan, percakapan acak (seed tetap), kasus angka (pembulatan), kasus parser.

    python tools/make_golden.py            # tulis ke web/tests/.generated/
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from difflib import SequenceMatcher
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.checker import Registry, normalize  # noqa: E402
from core.conversation import Bot, Session  # noqa: E402
from core.formatting import fmt_pct, fmt_rp  # noqa: E402
from core.parsing import parse_days, parse_rupiah, parse_yes_no  # noqa: E402

FIXTURES = ROOT / "tests" / "golden"
DEFAULT_OUT = ROOT / "web" / "tests" / ".generated"


def make_bot(complete: bool) -> Bot:
    reg = Registry.from_files(FIXTURES / "licensed.json", FIXTURES / "illegal.json")
    reg.complete = complete
    return Bot(reg)


def run_inputs(complete: bool, inputs):
    bot, session = make_bot(complete), Session()
    return [bot.handle(session, text) for text in inputs]


# ---------------------------------------------------------------- skenario tulisan tangan
def curated():
    scenarios = json.loads((FIXTURES / "scenarios.json").read_text(encoding="utf-8"))
    return [{**s, "expected": run_inputs(s["complete"], s["inputs"])} for s in scenarios]


# ---------------------------------------------------------------- percakapan acak
NAMES = [
    "RupiahCepat", "rupiah cepat", "RupiahCepet", "Rupiah Cepat Plus", "Danamas", "Danamaz", "Dana Mas",
    "danacepot", "danacepat", "DanaCepet", "PinjamMudah", "pinjam mudah", "Pinjam Mudahh", "Saku Kami",
    "SakuKamii", "Klik Kami", "KlikKamy", "klikkami pro", "Edufund", "Edufun", "DuitKilat", "<b>x</b>", "",
    "  ", "ab", "Rupiah Plus", "rupiahplus cair", "PT Pasar Dana Pinjaman", "Bank XYZ app", "🤖", "ÅÄÖ",
    "DanaKredi", "danakreditt", "PT Cepat Maju", "pinjol online",
]
NOISE = ["banyak", "0", "-5", "abc", "99999999999999", "1000000000000", "1000000000001", "", "5jt rb", "lima juta"]
TENORS = ["14 hari", "30", "3 bulan", "2 minggu", "0", "7hr", "1 bln", "99999", "abc", "3650", "3651 hari", "10 Hari",
          "45", "60 hari", "6 bulan"]


def amount_text(rng: random.Random, value: int) -> str:
    style = rng.randrange(7)
    if style == 0:
        return str(value)
    if style == 1:
        return f"{value:,}".replace(",", ".")
    if style == 2:
        return "Rp " + f"{value:,}".replace(",", ".")
    if style == 3 and value % 100_000 == 0:
        return f"{value / 1_000_000:g}jt".replace(".", rng.choice([".", ","]))
    if style == 4 and value % 100_000 == 0:
        return f"{value / 1_000_000:g} juta".replace(".", ",")
    if style == 5 and value % 1000 == 0:
        return f"{value // 1000}rb"
    if style == 6 and value % 1000 == 0:
        return f"{value // 1000}k"
    return str(value)


def random_value(rng: random.Random) -> int:
    kind = rng.randrange(4)
    if kind == 0:
        return rng.randrange(0, 40) * 500_000
    if kind == 1:
        return rng.randrange(1, 4000) * 5_000
    if kind == 2:
        return rng.randrange(1, 4_000_000) * 5  # sering berakhiran 5 -> uji pembulatan .5
    return rng.randrange(0, 200) * 100_000


def make_profile(rng: random.Random):
    """Profil keuangan masuk akal, supaya percakapan acak juga sampai ke hasil 'aman' / 'hati-hati',
    bukan hanya 'jangan'. Sebagian profil sengaja dibuat jatuh tepat di persen .5 (uji pembulatan)."""
    r = rng.random()
    if r < 0.15:  # cicilan berjalan tepat 12,5% penghasilan -> 12,5% harus tampil "12%" (setengah ke genap)
        income = rng.choice([4_000_000, 8_000_000, 16_000_000, 24_000_000, 40_000_000])
        installments = income // 8
    elif r < 0.75:
        income = rng.choice([rng.randrange(15, 200) * 100_000, rng.randrange(300_000, 4_000_000) * 5])
        installments = int(income * rng.choice([0, 0, 0, 0.05, 0.1, 0.15, 0.25, 0.35]) // 5000 * 5000)
    else:
        return None
    expenses = int(income * rng.uniform(0.15, 0.75) // 5000 * 5000)
    principal = max(50_000, int(income * rng.uniform(0.02, 0.6) // 50_000 * 50_000))
    return {"income": income, "expenses": expenses, "installments": installments, "principal": principal}


def pick_input(rng: random.Random, session: Session, profile=None) -> str:
    st = session.state.value
    if rng.random() < 0.06:
        return rng.choice(["menu", "bantuan", "?", "reset", "/start", "MENU "])
    if profile and st in profile and rng.random() < 0.9:
        return amount_text(rng, profile[st])
    if st == "menu":
        return rng.choice(["1", "2", "3", "3", "2", "cek", "hitung", "keduanya", "xyz", "", "Cek Legalitas"])
    if st == "check_name":
        return rng.choice(NAMES)
    if st == "confirm_match":
        return rng.choice(["1", "2", "3", "4", "bukan", "ya", "tidak", "²", "0", "abc", "1", "1"])
    if st == "ask_continue":
        return rng.choice(["ya", "tidak", "mungkin", "Ya!", "nggak?", "ya", "ya"])
    if st in ("income", "expenses", "installments", "principal"):
        if rng.random() < 0.12:
            return rng.choice(NOISE)
        return amount_text(rng, random_value(rng))
    if st == "total_repay":
        if rng.random() < 0.1:
            return rng.choice(NOISE)
        principal = session.data.get("principal", 1_000_000)
        factor = rng.choice([1.0, 1.02, 1.05, 1.1, 1.1, 1.2, 1.3, 1.5, 0.9])
        return amount_text(rng, int(round(principal * factor, -3)))
    if st == "tenor":
        return rng.choice(TENORS)
    if st == "other_debt":
        return rng.choice(["ya", "tidak", "tidak", "hmm"])
    if st == "after_result":
        return rng.choice(["lagi", "lagi", "menu", "coba lagi", "apa?", "LAGI"])
    return "menu"


def decorate(rng: random.Random, text: str) -> str:
    r = rng.random()
    if r < 0.08:
        return text.upper()
    if r < 0.16:
        return "  " + text + " \t"
    return text


def fuzz(n_sessions: int, steps: int, seed: int):
    rng = random.Random(seed)
    out = []
    for _ in range(n_sessions):
        complete = rng.random() < 0.5
        bot, session = make_bot(complete), Session()
        profile = make_profile(rng)
        inputs, expected = [], []
        for step in range(steps):
            text = "halo" if step == 0 else decorate(rng, pick_input(rng, session, profile))
            inputs.append(text)
            expected.append(bot.handle(session, text))
        out.append({"complete": complete, "inputs": inputs, "expected": expected})
    return out


# ---------------------------------------------------------------- angka & parser
def numeric(seed: int):
    rng = random.Random(seed)
    fixed = [(x, d) for x in (0.5, 1.5, 2.5, 12.5, 0.125, 0.375, 0.15, 0.25, 0.35, 0.45, 2.675, 99.995, 1e-7,
                              123456789.5, 0.0, -0.0, -0.5, -0.04, 1 / 3, 2 / 3, 0.1 + 0.2, 80.0, 12.5000001)
             for d in (0, 1, 2)]
    for _ in range(4000):
        kind = rng.randrange(4)
        if kind == 0:
            x = rng.uniform(0, 300)
        elif kind == 1:
            x = rng.randrange(0, 4000) / 8  # kelipatan 0,125 -> banyak persis-seri
        elif kind == 2:
            x = rng.randrange(0, 20000) / 4
        else:
            x = rng.randrange(0, 10**9) / 10**rng.randrange(0, 4)
        fixed.append((x, rng.randrange(0, 3)))
    rounds = [0.5, 1.5, 2.5, 3.5, -0.5, -1.5, 0.49999999999999994, 123456.5, 123457.5, 1e12 + 0.5]
    rounds += [rng.randrange(0, 10**7) / 2 for _ in range(1500)] + [rng.uniform(0, 1e9) for _ in range(500)]
    floordivs = [(a, 50000.0) for a in (0.0, 49999.99999999999, 50000.0, 149999.99999999997, 150000.0, 3.0e9)]
    floordivs += [(rng.uniform(0, 1e8), 50000.0) for _ in range(1500)]
    floordivs += [(rng.randrange(0, 2000) * 50000 * (1 - 2**-53), 50000.0) for _ in range(500)]
    money = [0, 1, 999, 1000, 12345, 1234567, -1900000, -1, -0.3, 2.5, 3.5, 300000.00000000006, 10**12] \
        + [rng.randrange(-10**8, 10**9) for _ in range(500)]
    texts = ["", " ", "5jt", "5 jt", "2,5 juta", "2.5jt", "750rb", "500k", "Rp 5.000.000", "rp.5000", "5.000", "5,000,000",
             "5000000", "0", "-5", "1.234", "12.34", "1,5k", "0,5jt", "1.500jt", "9999999jt", "1000000000000",
             "1000000000001", "٥٠٠٠", "５ｊｔ", "lima", "5 jt rb", "14 hari", "2 minggu", "3 bulan", "0 hari", "3650",
             "3651", "30 Hari", "14 hari", "ya", "Ya!", "tidak.", "nggak", "?", "ok", "bukan!!", "mungkin",
             "2.5", "2,", ",5", "1e5", "0x10", "5jt\n", "\t5jt", "5JT", "2,5 JUTA", "1 hr", "4 mgg", "5bln"]
    alphabet = list("0123456789.,jtrbkp ")
    texts += ["".join(rng.choice(alphabet) for _ in range(rng.randrange(1, 9))) for _ in range(1500)]

    # Skor kemiripan nama: difflib.SequenceMatcher(None, a, b).ratio() persis
    keys = sorted({normalize(x) for x in (
        "RupiahCepat", "PT Kredit Utama Fintech Indonesia", "Rupiah Cepat Plus", "Danamas", "PT Pasar Dana Pinjaman",
        "DanaKredi", "PT Pindar Berbagi Bersama", "Klik Kami", "PT Harapan Fintech Indonesia", "KlikKami Pro",
        "Edufund", "PT Fintech Bina Bangsa", "DanaCepat", "PT Cepat Maju", "PinjamMudah", "Saku Kami", "DanaCepet",
        "Rupiah Plus", "RupiahPlus Cair", "Kredivo", "Akulaku", "Amartha", "Investree", "KoinWorks", "Modalku")})
    sim = []

    def edit(s: str) -> str:
        s = list(s)
        for _ in range(rng.randrange(1, 4)):
            op, i = rng.randrange(4), rng.randrange(len(s) + 1)
            if op == 0 and s:
                del s[min(i, len(s) - 1)]
            elif op == 1:
                s.insert(i, rng.choice("abcdefghijklmnopqrstuvwxyz0123456789"))
            elif op == 2 and len(s) > 1:
                j = rng.randrange(len(s))
                s[min(i, len(s) - 1)], s[j] = s[j], s[min(i, len(s) - 1)]
            elif s:
                s[min(i, len(s) - 1)] = rng.choice("abcdefghijklmnopqrstuvwxyz")
        return "".join(s)

    for _ in range(3000):
        key = rng.choice(keys)
        q = edit(key) if rng.random() < 0.7 else rng.choice(keys)
        sim.append((q, key))
    for _ in range(1000):
        sim.append(("".join(rng.choice("abc") for _ in range(rng.randrange(0, 14))),
                    "".join(rng.choice("abc") for _ in range(rng.randrange(0, 14)))))
    return {
        "similarity": [{"a": a, "b": b, "out": SequenceMatcher(None, a, b).ratio()} for a, b in sim],
        "fixed": [{"x": x, "d": d, "out": f"{x:.{d}f}"} for x, d in fixed],
        "rounds": [{"x": x, "out": round(x)} for x in rounds],
        "floordivs": [{"a": a, "b": b, "out": a // b} for a, b in floordivs],
        "rp": [{"n": n, "out": fmt_rp(n)} for n in money],
        "pct": [{"x": x, "d": d, "out": fmt_pct(x, d)} for x, d in fixed[:600]],
        "parse": [{"text": t, "rupiah": parse_rupiah(t), "days": parse_days(t), "yesno": parse_yes_no(t)}
                  for t in texts],
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(DEFAULT_OUT))
    ap.add_argument("--sessions", type=int, default=250)
    ap.add_argument("--steps", type=int, default=18)
    ap.add_argument("--seed", type=int, default=20261024)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    cur, fz, num = curated(), fuzz(args.sessions, args.steps, args.seed), numeric(args.seed)
    (out / "curated.json").write_text(json.dumps(cur, ensure_ascii=False), encoding="utf-8")
    (out / "fuzz.json").write_text(json.dumps(fz, ensure_ascii=False), encoding="utf-8")
    (out / "numeric.json").write_text(json.dumps(num, ensure_ascii=False), encoding="utf-8")
    steps = sum(len(s["inputs"]) for s in cur) + sum(len(s["inputs"]) for s in fz)
    print(f"Acuan Python ditulis ke {out}: {len(cur)} skenario + {len(fz)} percakapan acak ({steps} langkah), "
          f"{sum(len(v) for v in num.values())} kasus angka/parser")


if __name__ == "__main__":
    main()
