# PinjolGuard (prototype)

Bot chat yang membantu orang sebelum mengambil pinjaman online:

1. **Cek legalitas**: user ketik nama aplikasi/platform, bot cek apakah tercatat *berizin OJK*, masuk daftar *ilegal*, atau *tidak ketemu*.
2. **Cek kemampuan bayar**: user isi penghasilan, pengeluaran, cicilan berjalan, dan tawaran pinjaman (jumlah, total bayar balik, tenor). Bot menghitung beban cicilan dan memberi status **Relatif aman / Hati-hati / Sebaiknya jangan**, plus *plafon aman* yang masuk akal untuk kondisi si user.

Tujuan kedua itu yang menjawab masalah "ngelebihin penghasilan demi limit tinggi": bot menunjukkan angka yang *sebenarnya mampu* dibayar, bukan limit yang ditawarkan aplikasi.

Tanpa dependensi eksternal. Python 3.9+ untuk versi terminal/API; versi web cukup browser (Node.js hanya dipakai untuk menjalankan tes).

## Tiga cara pakai, satu logika

```
core/            otak bot versi Python (tidak tahu soal channel)
  checker.py       cek legalitas (cocok persis / mirip / tidak ada)
  affordability.py hitung kemampuan bayar
  conversation.py  alur chat (state machine per user)
  parsing.py       baca "5jt", "2,5 juta", "750rb", "Rp 5.000.000"
v1_cli/          VERSI 1: simulasi chat di terminal
v2_api/          VERSI 2: API HTTP + adapter Telegram
web/             VERSI 3: situs web (HTML + JavaScript) untuk GitHub Pages
  core/            port JavaScript dari core/ (hasil harus identik, lihat bagian Tes)
data/            daftar platform (JSON), dipakai bersama oleh semua versi
tools/           csv_to_json.py (isi daftar resmi OJK), build_web.py, check_web.py, make_golden.py
tests/           tes Python + data acuan percakapan
.github/         workflow GitHub Actions: tes otomatis + deploy ke GitHub Pages
.devcontainer/   konfigurasi GitHub Codespaces
```

### Versi 1: terminal (paling cepat untuk demo)

```bash
python -m v1_cli.bot_cli
```

### Versi 2: API (siap disambung ke WhatsApp / Telegram)

```bash
python -m v2_api.server --port 8000
curl -X POST localhost:8000/chat -H 'Content-Type: application/json' \
     -d '{"user_id":"628123456789","text":"halo"}'
# -> {"replies": ["Halo! 👋 Aku PinjolGuard ...", ...]}
```

Satu `user_id` = satu sesi chat (di memori, hangus 30 menit setelah tidak aktif). Opsional: set `PINJOL_GUARD_API_KEY` lalu kirim header `X-API-Key`.

**Telegram** (disarankan untuk prototype, gratis, token jadi dalam 2 menit lewat @BotFather):

```bash
export TELEGRAM_BOT_TOKEN="isi_token_dari_BotFather"
python -m v2_api.telegram_poller
```

> Adapter Telegram diuji dengan transport palsu, **belum dicoba ke server Telegram asli**. Kalau error saat pertama jalan, cek tokennya dulu.

**WhatsApp**: nanti, setelah alur teruji. Pakai WhatsApp Business Platform (Cloud API) dari Meta: butuh akun bisnis Meta dan URL HTTPS publik untuk webhook, jadi lebih ribet untuk prototype. Webhook-nya cukup meneruskan nomor pengirim sebagai `user_id` dan isi pesan sebagai `text` ke logika yang sama (`Bot.handle`), lalu mengirim balik tiap item `replies`. Karena semua logika ada di `core/`, tidak ada yang perlu ditulis ulang.

### Versi 3: Web (GitHub Pages)

Bot yang sama sebagai halaman chat: bisa dibuka dari HP lewat satu tautan, tanpa install dan tanpa server. GitHub Pages hanya menyajikan file statis, jadi seluruh logika dijalankan **di browser** (port JavaScript dari `core/`). Akibatnya, penghasilan/pengeluaran yang diketik user tidak pernah dikirim ke server mana pun.

Coba di komputer sendiri:

```bash
python tools/build_web.py                  # merakit folder _site/
python -m http.server -d _site 8080        # lalu buka http://localhost:8080
```

(Jangan buka `index.html` langsung dari file; browser memblokir modul JavaScript dari `file://`. Halaman akan memberi petunjuk ini kalau itu terjadi.)

**Pasang ke GitHub Pages**, cukup sekali:

1. Push repo ke GitHub (lihat bagian paling bawah).
2. Di repo: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Setiap push ke branch `main`, workflow `.github/workflows/web.yml` menjalankan semua tes; kalau lulus, situs otomatis terbit di `https://<username>.github.io/<nama-repo>/`. Kalau ada tes gagal, situs tidak berubah.

Catatan: GitHub Pages untuk repo *private* umumnya butuh paket GitHub berbayar. Untuk repo publik gratis.

Mau mencoba tanpa install apa pun? Buka repo di **GitHub Codespaces** (tombol *Code → Codespaces*); `.devcontainer/` sudah menyiapkan Python dan Node, dan situs bisa dijalankan dengan perintah di atas. Konfigurasi Codespaces ini belum pernah diuji dari lingkungan pengembangan.

## ⚠️ Yang WAJIB kamu isi sebelum dipakai orang lain

**1. Daftar berizin (`data/licensed_platforms.json`) cuma contoh 5 nama.** Aku hanya bisa melihat cuplikan dari pemberitaan atas data OJK (94 penyelenggara berizin per 31 Agustus 2026), bukan daftar lengkapnya, dan lingkungan tempat ini dibuat tidak bisa mengunduh dari situs OJK. Karena itu file ditandai `"complete": false`, dan bot menjawab nama yang tak ditemukan dengan *"belum bisa bilang legal"*, **bukan** "ilegal".

Cara melengkapi: unduh daftar resmi dari situs OJK (halaman *Penyelenggara Fintech Lending Berizin di OJK*), simpan sebagai CSV dengan kolom `name,company,aliases`, lalu:

```bash
python tools/csv_to_json.py daftar_ojk.csv --as-of 2026-08-31 --complete
```

Opsi `--complete` membuat bot lebih tegas ("tidak ada di daftar pindar berizin"). Pakai hanya kalau daftarnya memang lengkap.

**2. Daftar ilegal (`data/illegal_platforms.json`) kosong.** Isi dari daftar resmi Satgas PASTI, dengan format yang sama seperti file berizin. Daftarnya terus berubah, jadi jadwalkan pembaruan rutin.

## Keputusan desain yang perlu kamu tahu

- **Bot memberi tahu user kalau platformnya ilegal.** Di pesanmu ada kalimat yang bisa dibaca "kalau ilegal, tidak dikasih tahu". Kuanggap itu salah ketik/salah dengar, karena bot yang menyembunyikan status ilegal justru membahayakan user. Kalau maksudmu lain, bilang saja, bagian itu ada di `Bot._report` (`core/conversation.py`).
- **Nama yang mirip tidak otomatis dianggap legal.** `RupiahCepet` → bot tanya "maksudmu RupiahCepat?" dulu, karena aplikasi ilegal sering meniru nama yang resmi.
- **"Tidak ada di daftar" ≠ "ilegal".** Paylater/kredit dari bank atau perusahaan pembiayaan memang tidak masuk daftar pindar. Bot mengarahkan user cek ke OJK 157 / WhatsApp 081 157 157 157 (kontak dari situs OJK).
- **Patokan hitungan adalah heuristik umum, bukan aturan OJK**: total cicilan ≤ 30% penghasilan = batas aman, > 40% = sebaiknya jangan, sisa uang minimal 10% penghasilan, dan biaya > 0,4%/hari dianggap mahal. Semua ada di `Policy` (`core/affordability.py`), tinggal ubah. Sebaiknya divalidasi ke ahli keuangan sebelum rilis publik. Bot selalu menutup hasilnya dengan penegasan bahwa ini bukan nasihat keuangan resmi.
- **Bot tidak bisa tahu apakah angka penghasilan itu jujur.** Bot hanya meminta user mengisi dengan jujur. Hasil hitungan cuma sebagus angka yang diketik.
- **Privasi**: data keuangan hanya ada di memori selama sesi, tidak ditulis ke disk, dan server tidak mencatat isi chat. Di versi web, hitungan terjadi sepenuhnya di browser user (tombol *Hapus chat* membuang sesinya). Kalau nanti kamu menyimpan riwayat, ingat itu data pribadi/keuangan (UU PDP).
- **Situs web bersifat publik.** Isi `illegal_platforms.json` hanya dari daftar resmi Satgas PASTI/OJK, dan cantumkan sumbernya di field `source` (tampil di peringatan). Menuduh sebuah platform ilegal tanpa dasar bisa bermasalah.

## Tes

```bash
python -m unittest discover -s tests -t .     # logika inti, CLI, API, Telegram (59 tes)
python tools/check_web.py                     # versi web == versi Python (butuh Node 18+)
```

**Kenapa ada tes khusus untuk versi web?** Logikanya ada dua salinan (Python dan JavaScript), dan perbedaan kecil bisa berbahaya di aplikasi keuangan: misalnya Python membulatkan 12,5 menjadi 12 (setengah ke genap), sedangkan JavaScript biasanya menjadi 13. `check_web.py` meminta Python menghasilkan "kunci jawaban" (27 skenario tulisan tangan, 250 percakapan acak dengan seed tetap, lebih dari 14.000 kasus angka, pembulatan, parser, dan skor kemiripan nama), lalu memastikan JavaScript membalas **huruf demi huruf** sama. Jadi kalau kamu mengubah teks balasan atau aturan hitungan di satu sisi, tes akan gagal sampai sisi lainnya disamakan. Setelah mengubah `core/`, port perubahan itu ke `web/core/`, lalu jalankan `python tools/check_web.py`.

Tampilan web sendiri (`web/app.js`, `index.html`, `style.css`) diuji manual di Chromium (alur chat, serangan XSS, layar HP, mode gelap), tapi uji browser itu belum disertakan di repo.

## Dorong ke GitHub

```bash
cd pinjol-guard
git init && git add . && git commit -m "PinjolGuard prototype"
git branch -M main
git remote add origin https://github.com/<username>/pinjol-guard.git
git push -u origin main
```

Lalu aktifkan Pages (Settings → Pages → Source: GitHub Actions) dan lihat tab **Actions** untuk memantau tes dan deploy pertama. Workflow-nya belum pernah dijalankan di GitHub sungguhan dari lingkungan pengembangan; kalau ada langkah yang gagal, salin pesan error-nya dan akan mudah diperbaiki.

Perubahan data (misalnya menambah daftar OJK) cukup edit `data/*.json` lalu push: situs ikut diperbarui otomatis.

## Sumber

- OJK, *Penyelenggara Fintech Lending Berizin di OJK* (daftar resmi dan kontak 157): https://www.ojk.go.id/id/kanal/iknb/data-dan-statistik/direktori/fintech/
- Pemberitaan atas data OJK, 94 pindar berizin per Agustus 2026 (sumber nama contoh di `data/`): https://infobanknews.com/hindari-pinjol-ilegal-ini-daftar-94-pindar-yang-resmi-berizin-ojk-september-2026
