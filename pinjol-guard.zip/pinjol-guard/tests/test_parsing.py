import unittest

from core.parsing import parse_days, parse_rupiah, parse_yes_no


class TestParseRupiah(unittest.TestCase):
    def test_formats(self):
        cases = {
            "5jt": 5_000_000,
            "5 jt": 5_000_000,
            "2,5 juta": 2_500_000,
            "2.5jt": 2_500_000,
            "750rb": 750_000,
            "750 ribu": 750_000,
            "500k": 500_000,
            "Rp 5.000.000": 5_000_000,
            "Rp. 5.000.000": 5_000_000,
            "5000000": 5_000_000,
            "5,000,000": 5_000_000,
            "0": 0,
            "  1jt ": 1_000_000,
        }
        for text, expected in cases.items():
            with self.subTest(text=text):
                self.assertEqual(parse_rupiah(text), expected)

    def test_invalid(self):
        for text in ["", "   ", "banyak", "lima juta", "-5jt", "5jt rb", "abc123"]:
            with self.subTest(text=text):
                self.assertIsNone(parse_rupiah(text))

    def test_absurd_and_non_ascii_digits_rejected(self):
        self.assertEqual(parse_rupiah("1000000000000"), 10**12)  # batas atas masih boleh
        for text in ["1000000000001", "99999999999999999999", "99999999jt", "٥٠٠٠", "５ｊｔ"]:
            with self.subTest(text=text):
                self.assertIsNone(parse_rupiah(text))


class TestParseDays(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(parse_days("30"), 30)
        self.assertEqual(parse_days("14 hari"), 14)
        self.assertEqual(parse_days("2 minggu"), 14)
        self.assertEqual(parse_days("3 bulan"), 90)

    def test_invalid(self):
        for text in ["", "0", "0 hari", "banyak", "99999", "-3"]:
            with self.subTest(text=text):
                self.assertIsNone(parse_days(text))


class TestYesNo(unittest.TestCase):
    def test_values(self):
        self.assertTrue(parse_yes_no("Ya!"))
        self.assertTrue(parse_yes_no("iya"))
        self.assertFalse(parse_yes_no("nggak"))
        self.assertFalse(parse_yes_no("Tidak."))
        self.assertIsNone(parse_yes_no("mungkin"))


if __name__ == "__main__":
    unittest.main()
