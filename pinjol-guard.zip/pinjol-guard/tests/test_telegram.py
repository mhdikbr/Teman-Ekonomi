import unittest

from core.checker import Platform, Registry
from core.conversation import Bot
from v2_api.server import SessionStore
from v2_api.telegram_poller import plain, process_update


def make():
    bot = Bot(Registry([Platform("RupiahCepat")], [Platform("PinjamMudah")]))
    sent = []
    return bot, SessionStore(), sent, lambda cid, text: sent.append((cid, text))


def upd(uid, chat, text):
    return {"update_id": uid, "message": {"chat": {"id": chat}, "text": text}}


class TestTelegram(unittest.TestCase):
    def test_replies_without_markdown_asterisks(self):
        bot, store, sent, send = make()
        process_update(upd(1, 42, "halo"), bot, store, send)
        self.assertEqual(sent[0][0], 42)
        self.assertNotIn("*", sent[0][1])
        self.assertIn("PinjolGuard", sent[0][1])

    def test_returns_update_id_and_keeps_per_chat_state(self):
        bot, store, sent, send = make()
        self.assertEqual(process_update(upd(7, 1, "halo"), bot, store, send), 7)
        process_update(upd(8, 1, "1"), bot, store, send)
        process_update(upd(9, 1, "PinjamMudah"), bot, store, send)
        self.assertIn("ILEGAL", sent[-2][1])
        sent.clear()
        process_update(upd(10, 2, "halo"), bot, store, send)  # chat lain mulai dari awal
        self.assertIn("PinjolGuard", sent[0][1])

    def test_ignores_non_text_updates(self):
        bot, store, sent, send = make()
        uid = process_update({"update_id": 5, "message": {"chat": {"id": 1}, "photo": []}}, bot, store, send)
        self.assertEqual(uid, 5)
        self.assertEqual(sent, [])
        self.assertEqual(process_update({"update_id": 6}, bot, store, send), 6)

    def test_plain(self):
        self.assertEqual(plain("*a* *b*"), "a b")


if __name__ == "__main__":
    unittest.main()
