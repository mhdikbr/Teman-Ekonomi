import unittest

from core.checker import Platform, Registry
from core.conversation import Bot, Session

LIC = [Platform("RupiahCepat", "PT Kredit Utama Fintech Indonesia")]
ILL = [Platform("PinjamMudah")]


def make_bot(complete=False):
    return Bot(Registry(LIC, ILL, licensed_as_of="2026-08-31", complete=complete))


def say(bot, s, *msgs):
    out = []
    for m in msgs:
        out = bot.handle(s, m)
    return "\n".join(out)


class TestFlows(unittest.TestCase):
    def test_first_message_shows_greeting(self):
        s = Session()
        self.assertIn("PinjolGuard", say(make_bot(), s, "halo"))

    def test_licensed_then_offer_to_continue(self):
        out = say(make_bot(), Session(), "halo", "1", "rupiah cepat")
        self.assertIn("berizin OJK", out)
        self.assertIn("lanjut hitung", out)

    def test_illegal_is_flagged_clearly(self):
        s = Session()
        out = say(make_bot(), s, "halo", "1", "Pinjam Mudah")
        self.assertIn("ILEGAL", out)
        self.assertNotIn("lanjut hitung", out)

    def test_illegal_in_combined_flow_does_not_continue_to_calc(self):
        s = Session()
        out = say(make_bot(), s, "halo", "3", "PinjamMudah")
        self.assertIn("ILEGAL", out)
        out = say(make_bot(), s, "5jt")  # tidak boleh diperlakukan sebagai penghasilan
        self.assertNotIn("Hasil hitungan", out)

    def test_unknown_with_incomplete_list_is_not_declared_legal_or_illegal(self):
        out = say(make_bot(complete=False), Session(), "halo", "1", "DuitKilat")
        self.assertIn("belum bisa bilang legal", out)
        self.assertNotIn("ILEGAL", out)
        self.assertNotIn("✅", out)

    def test_unknown_with_complete_list_says_not_proven_legal(self):
        out = say(make_bot(complete=True), Session(), "halo", "1", "DuitKilat")
        self.assertIn("tidak ada di daftar pindar berizin", out)

    def test_lookalike_asks_for_confirmation(self):
        s = Session()
        out = say(make_bot(), s, "halo", "1", "RupiahCepet")
        self.assertIn("mirip", out)
        out = say(make_bot(), s, "1")
        self.assertIn("berizin OJK", out)

    def test_unicode_digit_at_confirm_step_does_not_crash(self):
        s = Session()
        bot = make_bot()
        say(bot, s, "halo", "1", "RupiahCepet")
        self.assertIn("Balas nomor", say(bot, s, "²"))
        self.assertIn("Balas nomor", say(bot, s, "٣"))

    def test_lookalike_rejected(self):
        s = Session()
        out = say(make_bot(), s, "halo", "1", "RupiahCepet", "bukan")
        self.assertNotIn("✅", out)

    def test_full_calc_flow_risky_loan(self):
        s = Session()
        out = say(make_bot(), s, "halo", "2", "3jt", "2,5jt", "0", "2jt", "2,4jt", "30 hari", "tidak")
        self.assertIn("Hasil hitungan", out)
        self.assertIn("jangan diambil", out)

    def test_full_calc_flow_safe_loan(self):
        s = Session()
        out = say(make_bot(), s, "halo", "2", "10jt", "4jt", "0", "1jt", "1,1jt", "30", "tidak")
        self.assertIn("Relatif aman", out)

    def test_combined_flow_licensed_goes_straight_to_income(self):
        s = Session()
        out = say(make_bot(), s, "halo", "3", "RupiahCepat")
        self.assertIn("penghasilan bersih", out)

    def test_invalid_numbers_reprompt_without_advancing(self):
        s = Session()
        bot = make_bot()
        say(bot, s, "halo", "2")
        self.assertIn("belum paham", say(bot, s, "banyak"))
        self.assertIn("lebih dari 0", say(bot, s, "0"))
        self.assertIn("pengeluaran wajib", say(bot, s, "5jt"))

    def test_total_repay_smaller_than_principal_rejected(self):
        s = Session()
        out = say(make_bot(), s, "halo", "2", "5jt", "2jt", "0", "2jt", "1jt")
        self.assertIn("tidak mungkin lebih kecil", out)

    def test_retry_keeps_income_data(self):
        s = Session()
        bot = make_bot()
        say(bot, s, "halo", "2", "10jt", "4jt", "0", "1jt", "1,1jt", "30", "tidak")
        self.assertIn("jumlah pinjaman", say(bot, s, "lagi"))
        out = say(bot, s, "500rb", "550rb", "30", "tidak")
        self.assertIn("Hasil hitungan", out)

    def test_menu_resets_midway(self):
        s = Session()
        bot = make_bot()
        say(bot, s, "halo", "2", "10jt")
        self.assertIn("PinjolGuard", say(bot, s, "menu"))
        self.assertEqual(s.data, {})

    def test_bad_menu_choice(self):
        out = say(make_bot(), Session(), "halo", "xyz")
        self.assertIn("Pilih angka", out)

    def test_result_never_crashes_on_extreme_values(self):
        s = Session()
        out = say(make_bot(), s, "halo", "2", "1", "0", "0", "999999999999", "999999999999", "3650", "ya")
        self.assertIn("Hasil hitungan", out)


if __name__ == "__main__":
    unittest.main()
