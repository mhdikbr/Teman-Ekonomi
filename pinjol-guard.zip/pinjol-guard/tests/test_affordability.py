import unittest

from core.affordability import LoanOffer, Policy, Profile, Verdict, assess


class TestAssess(unittest.TestCase):
    def test_comfortable_loan_is_safe(self):
        a = assess(Profile(10_000_000, 4_000_000, 0), LoanOffer(1_000_000, 1_100_000, 30))
        self.assertEqual(a.verdict, Verdict.SAFE)
        self.assertEqual(a.monthly_installment, 1_100_000)
        self.assertEqual(a.free_after, 4_900_000)

    def test_loan_that_makes_budget_negative_is_avoid(self):
        a = assess(Profile(3_000_000, 2_500_000, 0), LoanOffer(2_000_000, 2_400_000, 30))
        self.assertEqual(a.verdict, Verdict.AVOID)
        self.assertLess(a.free_after, 0)
        # Sisa Rp500rb - buffer Rp300rb = ruang cicilan Rp200rb -> pinjaman ~Rp166rb -> dibulatkan Rp150rb
        self.assertEqual(a.max_safe_principal, 150_000)
        self.assertLess(a.max_safe_principal, 2_000_000)
        # Plafon itu aman dari sisi kemampuan bayar (verdict bisa tetap CAUTION karena biaya 20%/30 hari mahal)
        safe = assess(Profile(3_000_000, 2_500_000, 0), LoanOffer(150_000, 180_000, 30))
        self.assertNotEqual(safe.verdict, Verdict.AVOID)
        self.assertGreaterEqual(safe.free_after, 300_000)
        self.assertLessEqual(safe.dsr_after, Policy().max_dsr)

    def test_high_dsr_is_avoid(self):
        a = assess(Profile(5_000_000, 2_000_000, 500_000), LoanOffer(2_000_000, 2_200_000, 30))
        self.assertAlmostEqual(a.dsr_after, 0.54)
        self.assertEqual(a.verdict, Verdict.AVOID)

    def test_caution_band_between_30_and_40_percent(self):
        a = assess(Profile(10_000_000, 3_000_000, 0), LoanOffer(3_200_000, 3_500_000, 30))
        self.assertAlmostEqual(a.dsr_after, 0.35)
        self.assertEqual(a.verdict, Verdict.CAUTION)

    def test_expensive_short_loan_flagged(self):
        a = assess(Profile(10_000_000, 3_000_000, 0), LoanOffer(1_000_000, 1_150_000, 14))
        self.assertGreater(a.daily_cost_pct, 0.4)
        self.assertNotEqual(a.verdict, Verdict.SAFE)

    def test_paying_other_debt_never_safe(self):
        a = assess(Profile(10_000_000, 3_000_000, 0), LoanOffer(1_000_000, 1_050_000, 30, to_pay_other_debt=True))
        self.assertEqual(a.verdict, Verdict.CAUTION)

    def test_multi_month_tenor_splits_installments(self):
        a = assess(Profile(10_000_000, 4_000_000, 0), LoanOffer(3_000_000, 3_600_000, 90))
        self.assertEqual(a.n_installments, 3)
        self.assertEqual(a.monthly_installment, 1_200_000)

    def test_max_safe_principal_is_actually_safe(self):
        profile = Profile(6_000_000, 3_000_000, 500_000)
        base = LoanOffer(2_000_000, 2_300_000, 30)
        cap = assess(profile, base).max_safe_principal
        self.assertGreater(cap, 0)
        scaled = LoanOffer(cap, round(cap * 2_300_000 / 2_000_000), 30)
        self.assertNotEqual(assess(profile, scaled).verdict, Verdict.AVOID)
        self.assertLessEqual(assess(profile, scaled).dsr_after, Policy().max_dsr + 1e-9)

    def test_existing_debt_already_over_limit_gives_zero_cap(self):
        a = assess(Profile(5_000_000, 2_000_000, 2_000_000), LoanOffer(500_000, 550_000, 30))
        self.assertEqual(a.max_safe_principal, 0)

    def test_invalid_inputs(self):
        ok = LoanOffer(1_000_000, 1_100_000, 30)
        with self.assertRaises(ValueError):
            assess(Profile(0, 0, 0), ok)
        with self.assertRaises(ValueError):
            assess(Profile(5_000_000, -1, 0), ok)
        with self.assertRaises(ValueError):
            assess(Profile(5_000_000, 1, 0), LoanOffer(0, 0, 30))
        with self.assertRaises(ValueError):
            assess(Profile(5_000_000, 1, 0), LoanOffer(1_000_000, 900_000, 30))
        with self.assertRaises(ValueError):
            assess(Profile(5_000_000, 1, 0), LoanOffer(1_000_000, 1_100_000, 0))


if __name__ == "__main__":
    unittest.main()
