import unittest

from core.checker import Platform, Registry, Status, normalize

LICENSED = [
    Platform("RupiahCepat", "PT Kredit Utama Fintech Indonesia"),
    Platform("Danamas", "PT Pasar Dana Pinjaman"),
    Platform("Klik Kami", "PT Harapan Fintech Indonesia"),
]
ILLEGAL = [Platform("PinjamMudah"), Platform("Saku Kami")]


def reg(complete=False):
    return Registry(LICENSED, ILLEGAL, licensed_as_of="2026-08-31", complete=complete)


class TestNormalize(unittest.TestCase):
    def test_variants_collapse(self):
        for t in ["Rupiah Cepat", "rupiahcepat", "RUPIAH-CEPAT", "PT. RupiahCepat", "Aplikasi RupiahCepat"]:
            self.assertEqual(normalize(t), "rupiahcepat", t)

    def test_empty(self):
        self.assertEqual(normalize(""), "")
        self.assertEqual(normalize("!!!"), "")


class TestCheck(unittest.TestCase):
    def test_exact_licensed_any_casing(self):
        for q in ["RupiahCepat", "rupiah cepat", "RUPIAH CEPAT", "klik kami"]:
            self.assertEqual(reg().check(q).status, Status.LICENSED, q)

    def test_match_by_company_name(self):
        self.assertEqual(reg().check("PT Pasar Dana Pinjaman").status, Status.LICENSED)

    def test_reported_illegal(self):
        r = reg().check("pinjam mudah")
        self.assertEqual(r.status, Status.REPORTED_ILLEGAL)
        self.assertEqual(r.platform.name, "PinjamMudah")

    def test_illegal_wins_when_in_both_lists(self):
        r = Registry([Platform("Sama")], [Platform("Sama")])
        self.assertEqual(r.check("sama").status, Status.REPORTED_ILLEGAL)

    def test_lookalike_never_auto_licensed(self):
        r = reg().check("RupiahCepet")
        self.assertEqual(r.status, Status.POSSIBLE_MATCH)
        self.assertEqual(r.suggestions[0][0].name, "RupiahCepat")

    def test_unknown(self):
        self.assertEqual(reg().check("DuitKilatXYZ").status, Status.NOT_LISTED)

    def test_blank(self):
        self.assertEqual(reg().check("   ").status, Status.NOT_LISTED)

    def test_short_names_skip_fuzzy(self):
        self.assertEqual(reg().check("abc").status, Status.NOT_LISTED)

    def test_empty_registry(self):
        self.assertEqual(Registry([], []).check("apa saja").status, Status.NOT_LISTED)

    def test_shipped_data_loads(self):
        r = Registry.from_files()
        self.assertGreater(len(r.licensed), 0)
        self.assertFalse(r.complete)  # data contoh: jangan klaim lengkap
        self.assertEqual(r.check("Danamas").status, Status.LICENSED)


if __name__ == "__main__":
    unittest.main()
