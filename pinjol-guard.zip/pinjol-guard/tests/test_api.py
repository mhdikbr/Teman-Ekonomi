import json
import threading
import unittest
import urllib.error
import urllib.request

from core.checker import Platform, Registry
from core.conversation import Bot
from v2_api.server import SessionStore, create_server


def post(base, payload, headers=None, raw=None):
    body = raw if raw is not None else json.dumps(payload).encode()
    req = urllib.request.Request(base + "/chat", data=body, method="POST",
                                 headers={"Content-Type": "application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())


class ApiBase(unittest.TestCase):
    api_key = None

    @classmethod
    def setUpClass(cls):
        bot = Bot(Registry([Platform("RupiahCepat")], [Platform("PinjamMudah")]))
        cls.server = create_server("127.0.0.1", 0, bot, SessionStore(), api_key=cls.api_key)
        cls.base = f"http://127.0.0.1:{cls.server.server_address[1]}"
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()


class TestApi(ApiBase):
    def test_health(self):
        with urllib.request.urlopen(self.base + "/health", timeout=5) as r:
            self.assertEqual(json.loads(r.read()), {"ok": True})

    def test_conversation_keeps_state_per_user(self):
        code, out = post(self.base, {"user_id": "u1", "text": "halo"})
        self.assertEqual(code, 200)
        self.assertIn("PinjolGuard", out["replies"][0])
        post(self.base, {"user_id": "u1", "text": "1"})
        _, out = post(self.base, {"user_id": "u1", "text": "PinjamMudah"})
        self.assertIn("ILEGAL", out["replies"][0])

    def test_users_are_isolated(self):
        post(self.base, {"user_id": "a", "text": "halo"})
        post(self.base, {"user_id": "a", "text": "2"})
        _, out = post(self.base, {"user_id": "b", "text": "halo"})
        self.assertIn("PinjolGuard", out["replies"][0])

    def test_validation_errors(self):
        self.assertEqual(post(self.base, None, raw=b"not json")[0], 400)
        self.assertEqual(post(self.base, None, raw=b"[1,2]")[0], 400)
        self.assertEqual(post(self.base, {"text": "hi"})[0], 400)
        self.assertEqual(post(self.base, {"user_id": "", "text": "hi"})[0], 400)
        self.assertEqual(post(self.base, {"user_id": "u", "text": 5})[0], 400)
        self.assertEqual(post(self.base, {"user_id": "u", "text": "x" * 501})[0], 400)
        self.assertEqual(post(self.base, {"user_id": "u" * 65, "text": "hi"})[0], 400)

    def test_body_too_large(self):
        code, _ = post(self.base, {"user_id": "u", "text": "x" * 20000})
        self.assertEqual(code, 413)

    def test_unknown_path(self):
        req = urllib.request.Request(self.base + "/nope", data=b"{}", method="POST")
        with self.assertRaises(urllib.error.HTTPError) as cm:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(cm.exception.code, 404)


class TestApiKey(ApiBase):
    api_key = "rahasia"

    def test_requires_key(self):
        self.assertEqual(post(self.base, {"user_id": "u", "text": "hi"})[0], 401)
        self.assertEqual(post(self.base, {"user_id": "u", "text": "hi"}, {"X-API-Key": "salah"})[0], 401)
        self.assertEqual(post(self.base, {"user_id": "u", "text": "hi"}, {"X-API-Key": "rahasia"})[0], 200)


class TestSessionStore(unittest.TestCase):
    def test_expiry(self):
        store = SessionStore(ttl=0)
        s1 = store.get("x")
        s1.last_seen -= 10
        self.assertIsNot(store.get("x"), s1)

    def test_capacity_evicts_oldest(self):
        store = SessionStore(max_sessions=2)
        a = store.get("a"); a.last_seen -= 100
        store.get("b")
        store.get("c")
        self.assertEqual(set(store._items), {"b", "c"})


if __name__ == "__main__":
    unittest.main()
