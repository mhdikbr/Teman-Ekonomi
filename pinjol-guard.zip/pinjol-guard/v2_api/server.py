"""VERSI 2 - API HTTP (tanpa dependensi) yang siap disambung ke WhatsApp / Telegram.

Jalankan dari folder utama repo:
    python -m v2_api.server --port 8000

Endpoint:
    GET  /health
    POST /chat   body: {"user_id": "628123...", "text": "halo"}   ->   {"replies": ["...", "..."]}

Satu user_id = satu sesi percakapan (disimpan di memori saja, hangus setelah 30 menit tidak aktif).
Untuk WhatsApp/Telegram: webhook-nya cukup meneruskan nomor/ID pengirim sebagai user_id dan isi
pesan sebagai text, lalu mengirim balik setiap item di "replies" sebagai pesan.

Opsional: set env PINJOL_GUARD_API_KEY, lalu kirim header X-API-Key di setiap request.
"""
from __future__ import annotations

import argparse
import hmac
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Dict, Optional

from core.checker import Registry
from core.conversation import Bot, Session

MAX_BODY = 8 * 1024
MAX_TEXT = 500
MAX_USER_ID = 64
SESSION_TTL = 30 * 60
MAX_SESSIONS = 10_000


class SessionStore:
    """Sesi di memori dengan masa berlaku. Data keuangan user tidak pernah ditulis ke disk."""

    def __init__(self, ttl: int = SESSION_TTL, max_sessions: int = MAX_SESSIONS):
        self._ttl = ttl
        self._max = max_sessions
        self._items: Dict[str, Session] = {}
        self._lock = threading.Lock()

    def get(self, user_id: str) -> Session:
        now = time.time()
        with self._lock:
            for uid in [u for u, s in self._items.items() if now - s.last_seen > self._ttl]:
                del self._items[uid]
            session = self._items.get(user_id)
            if session is None:
                if len(self._items) >= self._max:
                    oldest = min(self._items, key=lambda u: self._items[u].last_seen)
                    del self._items[oldest]
                session = self._items[user_id] = Session()
            return session


def make_handler(bot: Bot, store: SessionStore, api_key: Optional[str]):
    bot_lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        server_version = "PinjolGuard/0.1"

        def _send(self, code: int, payload: dict) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:  # noqa: N802
            if self.path == "/health":
                self._send(200, {"ok": True})
            else:
                self._send(404, {"error": "not_found"})

        def do_POST(self) -> None:  # noqa: N802
            if self.path != "/chat":
                return self._send(404, {"error": "not_found"})
            if api_key:
                supplied = self.headers.get("X-API-Key", "")
                if not hmac.compare_digest(supplied.encode(), api_key.encode()):
                    return self._send(401, {"error": "unauthorized"})
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                return self._send(400, {"error": "bad_content_length"})
            if length <= 0:
                return self._send(400, {"error": "empty_body"})
            if length > MAX_BODY:
                self.close_connection = True
                return self._send(413, {"error": "body_too_large"})
            try:
                data = json.loads(self.rfile.read(length))
            except (ValueError, UnicodeDecodeError):
                return self._send(400, {"error": "invalid_json"})
            if not isinstance(data, dict):
                return self._send(400, {"error": "invalid_json"})
            user_id, text = data.get("user_id"), data.get("text")
            if not isinstance(user_id, str) or not user_id or len(user_id) > MAX_USER_ID:
                return self._send(400, {"error": "invalid_user_id"})
            if not isinstance(text, str) or len(text) > MAX_TEXT:
                return self._send(400, {"error": "invalid_text"})
            with bot_lock:
                replies = bot.handle(store.get(user_id), text)
            self._send(200, {"replies": replies})

        def log_message(self, fmt, *args) -> None:  # tidak mencatat apa pun soal user
            pass

    return Handler


def create_server(host: str, port: int, bot: Bot, store: Optional[SessionStore] = None,
                  api_key: Optional[str] = None) -> ThreadingHTTPServer:
    return ThreadingHTTPServer((host, port), make_handler(bot, store or SessionStore(), api_key))


def main() -> None:
    ap = argparse.ArgumentParser(description="PinjolGuard API (prototype)")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    args = ap.parse_args()
    server = create_server(args.host, args.port, Bot(Registry.from_files()),
                           api_key=os.environ.get("PINJOL_GUARD_API_KEY") or None)
    print(f"PinjolGuard API jalan di http://{args.host}:{args.port}  (POST /chat, GET /health)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
