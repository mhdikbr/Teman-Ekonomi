"""Adapter Telegram (long polling, tanpa dependensi) - cara tercepat mencoba bot di HP.

Langkah:
  1. Di Telegram, chat @BotFather -> /newbot -> salin token.
  2. export TELEGRAM_BOT_TOKEN="123456:ABC..."
  3. python -m v2_api.telegram_poller

CATATAN: kode ini diuji dengan transport palsu (tests/test_telegram.py), BELUM dicoba ke server
Telegram asli dari lingkungan pengembangan. Kalau ada error saat pertama jalan, cek token dulu.
Token tidak pernah dicetak ke log.
"""
from __future__ import annotations

import json
import os
import sys
import time
import urllib.parse
import urllib.request
from typing import Callable, Optional

from core.checker import Registry
from core.conversation import Bot
from v2_api.server import SessionStore

API = "https://api.telegram.org/bot{token}/{method}"


def _call(token: str, method: str, params: dict, timeout: int) -> dict:
    data = urllib.parse.urlencode(params).encode()
    req = urllib.request.Request(API.format(token=token, method=method), data=data, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def plain(text: str) -> str:
    """Telegram tidak memakai *tebal* gaya WhatsApp tanpa parse_mode; kirim polos supaya tidak
    pernah gagal gara-gara karakter markdown di input user."""
    return text.replace("*", "")


def process_update(update: dict, bot: Bot, store: SessionStore, send: Callable[[int, str], None]) -> Optional[int]:
    """Proses satu update. Mengembalikan update_id (untuk offset berikutnya)."""
    msg = update.get("message") or {}
    chat_id = (msg.get("chat") or {}).get("id")
    text = msg.get("text")
    if chat_id is not None and isinstance(text, str):
        for reply in bot.handle(store.get(f"tg:{chat_id}"), text[:500]):
            send(chat_id, plain(reply))
    return update.get("update_id")


def run(token: str, bot: Bot, call: Callable[[str, str, dict, int], dict] = _call) -> None:
    store = SessionStore()
    offset = 0

    def send(chat_id: int, text: str) -> None:
        call(token, "sendMessage", {"chat_id": chat_id, "text": text}, 15)

    print("Bot Telegram jalan. Ctrl+C untuk berhenti.")
    while True:
        try:
            res = call(token, "getUpdates", {"timeout": 25, "offset": offset}, 40)
            for update in res.get("result", []):
                uid = process_update(update, bot, store, send)
                if uid is not None:
                    offset = uid + 1
        except KeyboardInterrupt:
            return
        except Exception as e:  # jaringan putus, dll: jangan mati, jangan bocorkan token di pesan error
            print("Error:", type(e).__name__, file=sys.stderr)
            time.sleep(3)


def main() -> None:
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("Set dulu env TELEGRAM_BOT_TOKEN (token dari @BotFather).")
    run(token, Bot(Registry.from_files()))


if __name__ == "__main__":
    main()
