"""VERSI 1 - Simulasi chat di terminal.

Jalankan dari folder utama repo:
    python -m v1_cli.bot_cli
Ketik 'keluar' (atau Ctrl+C) untuk berhenti.
"""
from __future__ import annotations

import sys

from core.checker import Registry
from core.conversation import Bot, Session


def main() -> int:
    bot = Bot(Registry.from_files())
    session = Session()
    print("== PinjolGuard CLI (prototype). Ketik apa saja untuk mulai, 'keluar' untuk berhenti ==\n")
    while True:
        try:
            text = input("kamu> ")
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if text.strip().lower() in {"keluar", "exit", "quit"}:
            return 0
        for reply in bot.handle(session, text):
            print("\nbot>", reply.replace("\n", "\n     "), "\n")


if __name__ == "__main__":
    sys.exit(main())
